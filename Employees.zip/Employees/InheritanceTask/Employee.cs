namespace InheritanceTask
{
    public class Employee
    {
        private readonly string name;
        private decimal salary;
        private decimal bonus;

        public Employee(string name, decimal salary)
        {
            this.name = name;
            this.Salary = salary;
        }

        public string Name
        {
            get => name;
        }

        public decimal Salary
        {
            get => salary;
            set => salary = value;
        }

        public decimal Bonus
        {
            get => bonus;
            set => bonus = value;
        }

        public virtual void SetBonus(decimal bonus) => Bonus = bonus;

        public decimal ToPay() => Salary + Bonus;
    }
}