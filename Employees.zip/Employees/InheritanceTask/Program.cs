﻿using System;

namespace InheritanceTask
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}