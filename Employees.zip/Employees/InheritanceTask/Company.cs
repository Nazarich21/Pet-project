namespace InheritanceTask
{
    public class Company
    {
        private readonly Employee[] employees;

        public Company(Employee[] emp)
        {
            employees = emp;
        }

        public Employee[] Employees { get; set; }

        public void GiveEverybodyBonus(decimal companyBonus)
        {
            foreach (var employee in employees)
            {
                employee.SetBonus(companyBonus);
            }
        }

        public decimal TotalToPay()
        {
            decimal result = 0;
            foreach (var employee in employees)
             {result = result + employee.ToPay();}
            return result;
        }

        public string NameMaxSalary()
        {
            decimal max = 0;
            string name = string.Empty;
            foreach (var employee in employees)
            {
                if (employee.ToPay() > max)
                {
                    max = employee.ToPay();
                    name = employee.Name;
                }
            }
            return name;
        }
    }
}